package com.augmentedsociety.myphr.domain.validateRange;

public class SugarLevelRange 
{
	private int min;
	private int max;
	
	public SugarLevelRange(int max, int min)
	{
		this.max = max;
		this.min = min;
 	}
	
    public int getMin()
    {
    	return min;
    }
    
    public int getMax()
    {
    	return max;
    }
}
