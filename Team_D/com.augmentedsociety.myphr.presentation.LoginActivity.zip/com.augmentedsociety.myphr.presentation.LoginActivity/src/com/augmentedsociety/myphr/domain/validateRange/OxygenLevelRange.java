package com.augmentedsociety.myphr.domain.validateRange;

public class OxygenLevelRange 
{
	private int min;
	private int max;
	
	public OxygenLevelRange(int max, int min)
	{
		this.max = max;
		this.min = min;
 	}
	
    public int getMin()
    {
    	return min;
    }
    
    public int getMax()
    {
    	return max;
    }
}
