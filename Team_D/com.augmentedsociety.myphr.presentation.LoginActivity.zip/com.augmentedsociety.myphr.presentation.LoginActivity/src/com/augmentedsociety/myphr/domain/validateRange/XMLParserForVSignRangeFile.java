package com.augmentedsociety.myphr.domain.validateRange;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLParserForVSignRangeFile
{
    public static String BLOOD_SUGAR_XML_PATH = "config/blood_sugar.xml";
    public static String OXYGEN_LEVEL_XML_PATH = "config/oxygen_level.xml";
    public static String TEMPERATURE_XML_PATH = "config/temperature.xml";
    public static String PRESSURE_XML_PATH = "config/blood_pressure.xml";

        public static void main(String[] args)
		{
			 // parseTemperatureXML(TEMPERATURE_XML_PATH);
			 // parseSugarLevelXML(BLOOD_SUGAR_XML_PATH);
			 // parserOxygenLevelXML(OXYGEN_LEVEL_XML_PATH);
		}
	
	  public static TemperatureRange parseTemperatureXML(String configFilePath)
      { 
	  	  TemperatureRange temperatureRange = null;
		  try 
			{
				File fXmlFile = new File(configFilePath);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
				doc.getDocumentElement().normalize();
		
				NodeList icontrol_element = doc.getElementsByTagName("data");
				System.out.println(icontrol_element.getLength());
				for (int temp = 0; temp < icontrol_element.getLength(); temp++) 
				{
					Node nNode = icontrol_element.item(temp);		 
					if (nNode.getNodeType() == Node.ELEMENT_NODE) 
					{
						Element eElement = (Element) nNode;	
						String min = eElement.getElementsByTagName("min").item(0).getTextContent();

						String max = eElement.getElementsByTagName("max").item(0).getTextContent();

						System.out.println(min + " " + max);
						
						temperatureRange = new TemperatureRange(Integer.parseInt(max)
								 , Integer.parseInt(min));
						
						return temperatureRange;
					}
				}
				
			} 
		    catch (Exception e) 
		    {
				e.printStackTrace();
			}
		  
		return temperatureRange;
    }
	  
	  public static SugarLevelRange parseSugarLevelXML(String configFilePath)
      { 
		  SugarLevelRange sugarLevelRange = null;
		  try 
			{
				File fXmlFile = new File(configFilePath);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
				doc.getDocumentElement().normalize();
		
				NodeList icontrol_element = doc.getElementsByTagName("data");
				System.out.println(icontrol_element.getLength());
				for (int temp = 0; temp < icontrol_element.getLength(); temp++) 
				{
					Node nNode = icontrol_element.item(temp);		 
					if (nNode.getNodeType() == Node.ELEMENT_NODE) 
					{
						Element eElement = (Element) nNode;	
						String min = eElement.getElementsByTagName("min").item(0).getTextContent();

						String max = eElement.getElementsByTagName("max").item(0).getTextContent();

						System.out.println(min + " " + max);
						
						sugarLevelRange = new SugarLevelRange(Integer.parseInt(max)
								 , Integer.parseInt(min));
						
						return sugarLevelRange;
					}
				}
				
			} 
		    catch (Exception e) 
		    {
				e.printStackTrace();
			}
		  
		return sugarLevelRange;
    }
	  
	  public static OxygenLevelRange parserOxygenLevelXML(String configFilePath)
      { 
		  OxygenLevelRange sugarLevelRange = null;
		  try 
			{
				File fXmlFile = new File(configFilePath);
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
				doc.getDocumentElement().normalize();
		
				NodeList icontrol_element = doc.getElementsByTagName("data");
				System.out.println(icontrol_element.getLength());
				for (int temp = 0; temp < icontrol_element.getLength(); temp++) 
				{
					Node nNode = icontrol_element.item(temp);		 
					if (nNode.getNodeType() == Node.ELEMENT_NODE) 
					{
						Element eElement = (Element) nNode;	
						String min = eElement.getElementsByTagName("min").item(0).getTextContent();

						String max = eElement.getElementsByTagName("max").item(0).getTextContent();

						System.out.println(min + " " + max);
						
						sugarLevelRange = new OxygenLevelRange(Integer.parseInt(max)
								 , Integer.parseInt(min));
						
						return sugarLevelRange;
					}
				}
				
			} 
		    catch (Exception e) 
		    {
				e.printStackTrace();
			}
		  
		return sugarLevelRange;
    }
}
