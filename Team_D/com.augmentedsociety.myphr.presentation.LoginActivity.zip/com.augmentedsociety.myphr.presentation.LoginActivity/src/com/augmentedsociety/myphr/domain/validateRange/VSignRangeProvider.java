package com.augmentedsociety.myphr.domain.validateRange;

public class VSignRangeProvider
{
	
  private static OxygenLevelRange oxygenLevelRange;

	private static TemperatureRange temperatureRange;
	
  private static SugarLevelRange sugarLevelRange;
  
  public static OxygenLevelRange getOxygenLevelRange()
	{
			if( oxygenLevelRange == null)
			{
				 	oxygenLevelRange	= XMLParserForVSignRangeFile.
			 			 parserOxygenLevelXML(XMLParserForVSignRangeFile.OXYGEN_LEVEL_XML_PATH);
			}
  	
  		return oxygenLevelRange;
	}

	public TemperatureRange getTemperatureRange()
	{
		if( temperatureRange == null)
		{
		  	temperatureRange = XMLParserForVSignRangeFile.
		 			parseTemperatureXML(XMLParserForVSignRangeFile.TEMPERATURE_XML_PATH);
		}
		
		return temperatureRange;
	}

	public SugarLevelRange getSugarLevelRange()
	{
			if( sugarLevelRange == null)
			{
				 sugarLevelRange = XMLParserForVSignRangeFile.
			 			parseSugarLevelXML(XMLParserForVSignRangeFile.BLOOD_SUGAR_XML_PATH); 
			}
		
			return sugarLevelRange;
	}

}
