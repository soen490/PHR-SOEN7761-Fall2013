package com.augmentedsociety.myphr.domain.validateRange;

public class TemperatureRange 
{
	private int min;
	private int max;
	
	public TemperatureRange(int max, int min)
	{
		this.max = max;
		this.min = min;
 	}
	
    public int getMin()
    {
    	return min;
    }
    
    public int getMax()
    {
    	return max;
    }
}
